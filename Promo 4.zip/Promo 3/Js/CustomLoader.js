export function ShowLoader(target = document.body) {
  const existing = document.querySelector(".CustomLoader");
  if (existing) return;

  const loader = document.createElement("div");
  loader.className = "CustomLoader";

  loader.innerHTML = `
    <div class="spinner"></div>
  `;

  const computedStyle = window.getComputedStyle(target);
  if (computedStyle.position === "static") {
    target.style.position = "relative";
  }

  target.appendChild(loader);
}

export function HideLoader() {
  const loader = document.querySelector(".CustomLoader");
  if (loader) loader.remove();
}
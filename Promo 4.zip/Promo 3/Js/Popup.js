const Overlay = document.querySelector(".PopupOverlay");

// Add Plane Popup Start
const OpenPopup = document.querySelector(".AddPlane");
const ClosePopup = document.querySelector(".CloseAddPlanePopup");

OpenPopup.addEventListener('click', () => {
    Overlay.style.display = 'flex';
    document.body.classList.add('DisableScroll');
});

ClosePopup.addEventListener('click', () => {
    Overlay.style.display = 'none';
    document.body.classList.remove('DisableScroll');
});
// Add Plane Popup End
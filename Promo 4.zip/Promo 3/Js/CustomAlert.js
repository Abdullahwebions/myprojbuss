export function ShowAlert(message, type = "success") {
  const existingAlert = document.querySelector(".CustomAlert");
  if (existingAlert) existingAlert.remove();

  const alertBox = document.createElement("div");
  alertBox.className = `CustomAlert ${type}`;
  alertBox.innerHTML = `
    <i class="ri-close-large-line CloseAlert"></i>
    <span>${message}</span>
  `;

  document.body.appendChild(alertBox);
  alertBox.querySelector(".CloseAlert").onclick = () => alertBox.remove();
  setTimeout(() => alertBox.remove(), 3500);
}
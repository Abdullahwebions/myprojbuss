import {createClient} from "https://cdn.skypack.dev/@supabase/supabase-js";;

export const db = createClient("https://mfxwjqyrncbtkcxsxbrq.supabase.co", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1meHdqcXlybmNidGtjeHN4YnJxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTQ2ODYyMjQsImV4cCI6MjA3MDI2MjIyNH0.972S222vuDINfb2mHusQHgckOY69gG-9oDMt33PgRtU");